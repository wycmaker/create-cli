const { defineConfig } = require('@vue/cli-service')
const AutoImport = require('unplugin-auto-import/webpack')
const Components = require('unplugin-vue-components/webpack')
const { ElementPlusResolver } = require('unplugin-vue-components/resolvers')

module.exports = defineConfig({
  transpileDependencies: true,
  css: {
    loaderOptions: {
      scss: {
        additionalData: `@import "~@/assets/css/custom.scss";`
      }
    }
  },
  configureWebpack: {
    resolve: {
      alias: {
        Components: '@/components'
      }
    },
    plugins: [
      require('unplugin-element-plus/webpack')({
        libs: [{
          libraryName: 'element-plus',
          esModule: true,
          resolveStyle: (name) => {
            return `element-plus/theme-chalk/${name}.css`
          }
        }]
      }),
      AutoImport({
        include: [
          /\.[tj]sx?$/, // .ts, .tsx, .js, .jsx
          /\.vue$/, /\.vue\?vue/, // .vue
          /\.md$/, // .md
        ],
        resolvers: [
          ElementPlusResolver()
        ],
        imports: [ 
          'vue',
          {
            'vue-router': [ 'createRouter', 'createWebHashHistory' ]
          },
          {
            'vuex': [ 
              'createStore', 'useStore'
            ]
          },
          {
            'axios': [
              [ 'default', 'axios' ]
            ]
          },
          {
            'vue-toastification': [
              'useToast',
              [ 'default', 'Toast' ]
            ]
          },
          {
            'crypto-js': [
              [ 'default', 'CryptoJS' ]
            ]
          },
          {
            '@/plugins/ElementPlusIcon': [
              [ 'default', 'ElementPlusIcons' ]
            ]
          }
        ],
        dirs: [  
          './src/apiservices/',
          './src/apiservices/apis',
          './src/composables/',
          './src/services/common/', 
          './src/services/system/',
          './src/store',
          './src/router',
          './src/props/'
        ]
      }),
      Components({
        resolvers: [
          ElementPlusResolver()
        ]
      })
    ]
  },
  publicPath: process.env.VUE_PUBLISH_PATH,
  outputDir: process.env.VUE_OUTOUT_DIR,
  assetsDir: './static',
  chainWebpack: (config) => {
    config.plugin("html").tap((args) => {
      args[0].inject = false
      return args
    })
  },
  productionSourceMap: process.env.NODE_ENV === 'production' ? false : true,
  devServer: {
    proxy: {
      '/api': {
        target: process.env.VUE_APP_DEV_PROXY,
        changeOrigin: true,
        secure: false,
        pathRewrite: {
          '^/api': '/api'
        }
      }
    }
  }
})
