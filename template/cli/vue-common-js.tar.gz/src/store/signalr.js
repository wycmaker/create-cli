export default {
  state: {
    msgList: []
  },
  getters: {
    msgListInfo(state) {
      return state.msgList
    }
  },
  mutations: {
    /**
     * 新增提醒訊息
     * @param {object} state Vuex state物件
     * @param {string} text 訊息文字 
     */
    addmessage(state, text) {
      state.msgList.push(text)
    }
  },
  actions: {
  },
  modules: {
  },
  strict: true
}
