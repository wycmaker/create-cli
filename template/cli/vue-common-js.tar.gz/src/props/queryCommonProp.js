export default {
  title: {
    type: String,
    default: ''
  },
  titleWidth: {
    type: String,
    default: ''
  },
  width: {
    type: String,
    default: '160px'
  }
}