const host = process.env.WEBPACK_DEV_SERVER_URL !== undefined ? process.env.VUE_APP_API_ROOT : process.env.VUE_APP_DEV_PROXY
const connection = hubConnection(host, {})
const hubProxy = connection.createHubProxy(process.env.VUE_APP_SIGNALR_HUB)
let tryingConnection = false

/**
 * 初始化Singalr連線
 */
export const init = () => {
  start()
  connection.reconnecting(_ => {
    console.log('重新連接....')
    tryingConnection = true
  })
  
  connection.reconnected(_ => {
    console.log('成功重新連接....')
    tryingConnection = false
  })
  
  connection.disconnected(_ => {
    console.log('連線中斷....')
    if(tryingConnection) {
      setTimeout(function () {
        start()
      }, 5000)
    }
  })

}

/**
 * 加入Signalr通知事件
 * @param {string} name 事件名稱
 * @param {callback} func 通知事件處理
 */
export const addEvent = (name, func) => {
  hubProxy.on(name, func)
}

/**
 * 關閉Signalr連線
 */
export const close = () => {
  connection.stop()
}

/**
 * 開啟Signalr連線
 */
const start = () => {
  connection
    .start({ jsonp: true })
    .done(_ => { console.log('連線成功建立') })
    .fail(_ => { console.log('無法建立連線') })
}
