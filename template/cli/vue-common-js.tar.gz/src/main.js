import App from './App.vue'
import 'vue-toastification/dist/index.css'
import './services/common/commonMethod'

// 路由跳轉處理
routerProcess()

const app = createApp(App).use(Toast).use(store).use(router).use(ElementPlusIcons)

app.mount('#app')
