<template>
  <div :class="[$style.query]">
    <slot></slot>
  </div>
</template>

<script setup lang="ts">

</script>

<style lang="scss" module>

</style>
