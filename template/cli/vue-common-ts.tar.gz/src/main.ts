import App from './App.vue'
import 'vue-toastification/dist/index.css'
import './extensions'

const app = createApp(App)

app.use(store)
app.use(router)
app.use(Toast)
app.use(ElementPlusIcons)

app.mount('#app')

routerProcess()
