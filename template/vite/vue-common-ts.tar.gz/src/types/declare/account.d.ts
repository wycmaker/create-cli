export {}

declare global {
  type LoginAttr = {
    account: string,
    password: string
  }
}