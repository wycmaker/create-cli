const reloadInjectKey: InjectionKey<() => void> = Symbol('')
export default reloadInjectKey