import App from './App.vue'
import 'vue-toastification/dist/index.css'
import './extensions'

console.log(import.meta.env.VITE_APP_MODE)

const app = createApp(App)

app.use(store)
app.use(router)
app.use(Toast)
app.use(ElementPlusIcons)

app.mount('#app')

routerProcess()
