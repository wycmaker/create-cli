export default {
  label: {
    type: String,
    default: ''
  },
  width: {
    type: String,
    default: ''
  },
  align: {
    type: String,
    default: 'left'
  },
  prop: {
    typs: String,
    default: ''
  },
  fix: {
    type: String,
    default: ''
  },
  className: {
    type: String,
    default: ''
  }
}