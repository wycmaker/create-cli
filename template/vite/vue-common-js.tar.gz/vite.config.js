import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
import AutoImport from 'unplugin-auto-import/vite'
import ElementPlus from 'unplugin-element-plus/vite'

export default({ mode }) => {
  process.env = { ...process.env, ...loadEnv(mode, process.cwd()) }

  return defineConfig({
    base: process.env.VITE_PUBLISH_PATH,
    build: {
      outDir: process.env.VITE_OUTPUT_DIR,
    },
    css: {
      modules: {
        localsConvention: 'camelCase'
      },
      preprocessorOptions: {
        scss: {
          additionalData: '@import "@/assets/css/custom.scss";'
        }
      }
    },
    resolve: {
      alias: {
        '@': '/src'
      }
    },
    plugins: [
      vue(),
      ElementPlus({}),
      AutoImport({
        resolvers: [
          ElementPlusResolver()
        ],
        imports: [
          'vue',
          {
            'vue-router': [
              'createRouter',
              'createWebHashHistory'
            ]
          },
          {
            'pinia': [
              'createPinia', 
              'defineStore'
            ]
          },
          {
            'axios': [
              [ 'default', 'axios' ]
            ]
          },
          {
            'vue-toastification': [
              'useToast',
              [ 'default', 'Toast' ]
            ]
          },
          {
            'crypto-js': [
              [ 'default', 'CryptoJS' ]
            ]
          },
          {
            '@/plugins/ElementPlusIcon': [
              [ 'default', 'ElementPlusIcons' ]
            ]
          }
        ],
        dirs: [
          './src/apiservices/',
          './src/apiservices/apis',
          './src/composables/',
          './src/router',
          './src/services/common/', 
          './src/services/system/',
          './src/store',
          './src/props/'
        ]
      }),
      Components({
        resolvers: [
          ElementPlusResolver()
        ]
      }),
      {
        name: 'inject-nonce-and-change-src',
        enforce: 'post',
        transformIndexHtml(html) {
          let scriptNonce = /<script(.*?)/gi
          let scriptNonceReplacement = `<script nonce="${'CD2A0D791B21FD3084CB8A3FEFA27EBEF27F5268490F8ADC85D241D4D50AC9FC=='}"$1`
          let styleNonce = /<link(.*?)/gi
          let styleNonceReplacement = `<link nonce="${'CD2A0D791B21FD3084CB8A3FEFA27EBEF27F5268490F8ADC85D241D4D50AC9FC=='}"$1`
          return html.replace(scriptNonce, scriptNonceReplacement).replace(styleNonce, styleNonceReplacement)
        }
      }
    ],
    server: {
      proxy: {
        '/api': {
          target: process.env.VITE_SERVER_URL,
          changeOrigin: true,
          rewrite: path => path.replace(/^\/api/, '/api')
        }
      }
    }
  })
}
