String.prototype.getPath = function () {
  return this.substring(2, this.length);
}