const { app, protocol, BrowserWindow } = require('electron')
const isDevelopment = process.env.NODE_ENV === 'development'

protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { secure: true, standard: true } }
])
 
async function createWindow () {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
  })

  win.setMenuBarVisibility(false)
 
  // 加载 index.html
  if(isDevelopment) await win.loadURL(process.env.VITE_DEV_SERVER_HOST)
  else win.loadFile('./index.html')
}

app.whenReady().then(() => {
  createWindow()
 
  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})