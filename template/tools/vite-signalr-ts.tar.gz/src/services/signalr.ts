const host = import.meta.env.VITE_APP_MODE === 'development' ? import.meta.env.VITE_API_ROOT : import.meta.env.VITE_SERVER_URL
const connection = hubConnection(host, {})
const hubProxy = connection.createHubProxy(import.meta.env.VITE_SIGNALR_HUB)
let tryingConnection = false

/**
 * 初始化Singalr連線
 */
export const init = () => {
  start()
  connection.reconnecting(() => {
    console.log('重新連接....')
    tryingConnection = true
  })
  
  connection.reconnected(() => {
    console.log('成功重新連接....')
    tryingConnection = false
  })
  
  connection.disconnected(() => {
    console.log('連線中斷....')
    if(tryingConnection) {
      setTimeout(function () {
        start()
      }, 5000)
    }
  })

}

/**
 * 加入Signalr通知事件
 * @param name 事件名稱
 * @param func 通知事件處理
 */
export const addEvent = (name:string, func:Function) => {
  hubProxy.on(name, func)
}

/**
 * 關閉Signalr連線
 */
export const close = () => {
  connection.stop()
}

/**
 * 開啟Signalr連線
 */
const start = () => {
  connection
    .start({ jsonp: true })
    .done(() => { console.log('連線成功建立') })
    .fail(() => { console.log('無法建立連線') })
}
