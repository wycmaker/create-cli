export const signalrStore = defineStore('signalr', {
  state: () => {
    return {
      msgList: [] as Array<any>
    }
  },
  actions: {
    /**
     * 新增提醒訊息
     * @param {object} state Vuex state物件
     * @param {string} text 訊息文字 
     */
    addmessage(text: string) {
      this.msgList.push(text)
    }
  }
})