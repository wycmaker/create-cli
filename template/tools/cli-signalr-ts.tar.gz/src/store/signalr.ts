interface SignalRStore {
  msgList: Array<any>
}

export default {
  state: {
    msgList: []
  } as SignalRStore,
  getters: {
    msgListInfo(state:SignalRStore) {
      return state.msgList
    }
  },
  mutations: {
    /**
     * 新增提醒訊息
     * @param state Vuex state物件
     * @param text 訊息文字 
     */
    addmessage(state:SignalRStore, text:string) {
      state.msgList.push(text)
    }
  },
  actions: {
  },
  modules: {
  },
  strict: true
}
